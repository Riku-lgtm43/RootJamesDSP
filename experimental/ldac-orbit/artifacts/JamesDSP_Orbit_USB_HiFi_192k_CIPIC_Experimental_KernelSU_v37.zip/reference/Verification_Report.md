# JamesDSP Orbit — USB HiFi 192 kHz v37 Verification Report

This is the v37 experimental USB HiFi 192 kHz candidate. Its route finding,
source change, build identity, tests, limits, and checksum are in
[`USB_HiFi_192k_Verification_Report.md`](USB_HiFi_192k_Verification_Report.md).
The v36 RMS normalization and headroom measurements remain in
[`AudioQuality_Verification_Report.md`](AudioQuality_Verification_Report.md).
