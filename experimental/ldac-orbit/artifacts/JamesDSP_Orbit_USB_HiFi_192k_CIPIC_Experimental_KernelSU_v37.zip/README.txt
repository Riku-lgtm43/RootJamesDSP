JamesDSP Orbit Stage 31 — USB HiFi 192 kHz Orbit Support
Experimental KernelSU update — version 37
===============================================================================

STATUS
- This is an opt-in experimental update to the v36 candidate. The Stage 31
  release and v36 ZIP remain unchanged.
- The supplied Android 16 capture shows the active USB effect at stereo-float
  192 kHz. The v36 Orbit selector used Steam Audio's embedded HRTF at 192 kHz.
  Exact-library checks confirm embedded entries at 24/44.1/48 kHz and failures
  at 88.2/96 kHz. The exact Android 192 kHz check remains pending, so this
  rate-selection mismatch is the strongest source-level explanation for Orbit
  not working, with the 192 kHz initialization failure still to be confirmed.
- Version 37 keeps the embedded HRTF at 24/44.1/48 kHz and selects bundled
  CIPIC SOFA for other rates, including 192 kHz. Steam Audio 4.8.1 Linux host
  tests created and processed CIPIC HRTFs at 192 kHz with bounded finite output.
  The exact Android ARM64 library matrix and 192 kHz device playback remain
  pending.
- The capture's AudioFlinger mixer rate is 192 kHz while the ALSA USB snapshot
  reports 48 kHz. This ZIP does not establish the DAC hardware's active rate.
- Enhanced mode remains the only route evidenced by the capture to attach
  JamesDSP to this active HiFi session. This native Orbit change does not alter
  Enhanced-mode lifecycle or resolve its reported stability concerns.
- The 128-frame Orbit bridge still adds up to 128 frames of latency. This is
  not a production-stable release.

IDENTITY AND PRESERVED FILES
- KernelSU module ID remains jamesdsp_orbit_stage29. Install only as an
  in-place opt-in update, never as a second module.
- The signed JamesDSP APK and certificate, audio_effects.xml,
  libc++_shared.so, libphonon.so, customize.sh, CIPIC SOFA data, license notice,
  and Orbit effect UUID are preserved byte-for-byte from v36.
- Only the Orbit SteamSpatial object was rebuilt. The other 89 object inputs
  are byte-identical to v36.
- No JKS, signing password, or signing secret is included.

INSTALL AND ROLLBACK
1. Back up the installed module, app settings, and known-good Stage 31 ZIP.
2. Install through KernelSU Manager as an in-place update; do not flash from
   recovery or install a second module.
3. Test briefly at low volume with Orbit OFF/ON at USB 192 kHz. Also verify
   ordinary 44.1/48 kHz playback and AAC/USB controls. Stop on crackle, pops,
   dropouts, silence, abnormal balance, or volume.
4. For rollback, disable the experimental module in KernelSU Manager and
   reboot, then restore the saved Stage 31 package and reboot.

VERIFICATION
See reference/USB_HiFi_192k_Verification_Report.md for the route finding,
native change, build identity, tests, and limitations. The ZIP checksum is
published in the matching .sha256 sidecar. See
reference/AudioQuality_Verification_Report.md for the unchanged v36 headroom
measurements. The CIPIC redistribution notice is at
licenses/CIPIC-HRTF-NOTICE.txt.
