#!/system/bin/sh
# Sourced by KernelSU after extraction. No direct system partition writes.
[ "$ARCH" = arm64 ] || abort '! This build supports arm64 only.'
[ -d "$MODPATH/system/vendor/lib64/soundfx" ] || abort '! Missing vendor soundfx directory.'
[ -f "$MODPATH/system/vendor/etc/audio_effects.xml" ] || abort '! Missing vendor audio effects XML.'
if [ -d /data/adb/modules/jamesdsp_orbit_stage23 ] && [ ! -f /data/adb/modules/jamesdsp_orbit_stage23/disable ]; then
  abort '! Disable JamesDSP Stage23 in KernelSU before installing Stage31.'
fi
ui_print '- Setting SELinux labels on overlay payload'
set_perm_recursive "$MODPATH/system/vendor" 0 0 0755 0644 u:object_r:vendor_file:s0
if [ -d "$MODPATH/system/vendor/etc" ]; then
  set_perm_recursive "$MODPATH/system/vendor/etc" 0 0 0755 0644 u:object_r:vendor_configs_file:s0
fi
ui_print '- Vendor config files use vendor_configs_file; soundfx libraries use vendor_file'
ui_print '- No SELinux policy changes, no live partition writes'
ui_print '- Reboot required: check labels and effect registration after boot'
