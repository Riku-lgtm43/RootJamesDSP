JamesDSP Orbit Stage 31 — USB HiFi 192 kHz HRTF level correction
Experimental KernelSU update — version 40
===============================================================================

SCOPE
- Based on the v38 Android 16 config-label package.
- Applies one native Orbit change: HRTF volume is 0.25 only at exactly
  192,000 Hz; all other rates keep the v38 value.
- Does not include Enhanced mode session discovery, active playback config
  changes, PCM pass-through fallback, or app/APK updates.
- Module ID remains jamesdsp_orbit_stage29. Install only as an in-place update,
  not as a second module.

PRESERVED CONTENT
- The signed JamesDSP APK and certificate, JamesDSP DSP/effect core objects,
  Steam Audio library, libc++_shared.so, audio_effects.xml, CIPIC HRTF data,
  attribution notice, and v38 Android 16 config-label installer are unchanged.
- No private keystore, password, or signing secret is included.

DEVICE STATUS
- The corrected native library was built and packaged for ARM64. ZIP integrity,
  protected payload hashes, APK signature, ELF architecture, dynamic exports,
  required libraries, and RUNPATH were checked.
- The v40 candidate has not been installed or listened to on-device. Confirm
  192 kHz USB playback at low volume before regular use. Stop and disable the
  module if you hear distortion, harshness, crackling, pops, dropouts, silence,
  or abnormal levels.

INSTALL AND ROLLBACK
1. Back up the installed module, settings, and known-good Stage 31 ZIP.
2. Install this ZIP as an in-place update in KernelSU Manager.
3. To roll back, disable the experimental module and reboot. Restore the saved
   known-good module ZIP if needed, then reboot again. Keep recovery access
   available in case the device does not boot normally.

See reference/192k_HRTF_LevelOnly_Verification_Report.md for the verification
record and remaining device checks. The CIPIC redistribution notice is in
licenses/CIPIC-HRTF-NOTICE.txt.
