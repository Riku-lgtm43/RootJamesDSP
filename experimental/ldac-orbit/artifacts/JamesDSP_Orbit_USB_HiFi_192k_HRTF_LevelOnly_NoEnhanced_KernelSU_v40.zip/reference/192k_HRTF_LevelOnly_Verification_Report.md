# JamesDSP Orbit Stage 31 — 192 kHz HRTF level-only v40

**Status:** Experimental candidate. It has not been installed or listened to on-device.

## Change scope

This candidate is based on the v38 Android 16 config-label KernelSU ZIP. The
only audio-processing change is in `SteamSpatial.cpp`:

```cpp
hrtfSettings.volume = mSampleRate == 192000 ? 0.25f : 1.0f;
```

At 192 kHz the CIPIC HRTF had a measured level increase relative to the 48 kHz
reference. The conditional reduces HRTF output level at exactly 192 kHz. Other
sample rates retain the v38 value. It does not alter the Orbit blend, bass
preservation, dry signal, DSP algorithms, or JamesDSP app.

The v39 PCM pass-through fallback is excluded. The JamesDSP APK and app-session
code are unchanged, and the module does not introduce Enhanced mode session or
active playback configuration updates.

## Build and package checks

- Base package: v38, SHA-256
  `cf4e421c4c4a166c7c1a5aecba3d5d564dba666b754a9c3c9adef9c39d74a34f`.
- Built the `orbit_SteamSpatial.cpp.o` object with Android NDK r27
  (27.0.12077973), Clang, target API 26, `-std=c++17 -fPIC -O2`, and the
  Stage 31 Steam Audio headers.
- Linked against the v38 native object set, retaining the existing v38
  `jamesdsp.c.o`. Only the Orbit spatial object was replaced; the PCM fallback
  object from the historical v39 package was not used.
- The new Orbit object SHA-256 is
  `c42330d56b8509950f8971711e50730ebe73b1f82cb12ed40b3ec82b30a395ea`.
- The ARM64 `libjamesdsp_orbit.so` SHA-256 is
  `34fd8f4102ed92c2c252c7fb1ddf5483a0b614b9839ef836ee8cb642439ee680`.
  ELF class, machine, exports, NEEDED libraries, and
  `/vendor/lib64/soundfx` RUNPATH match v38.
- Module ID remains `jamesdsp_orbit_stage29`.
- The APK SHA-256 remains
  `e37ee0373e0fbb43147dbe10e7af617d45ab53203339c3904d86c8fba2d96eb2`;
  apksigner v2/v3 verification and certificate match the v38 package.
- The signed APK, `libphonon.so`, `libc++_shared.so`, `audio_effects.xml`,
  CIPIC SOFA, attribution notice, installer, and every other v38 package
  payload are byte-identical. The inner ZIP integrity check passed.

## Remaining checks

The new 192 kHz level correction requires listening confirmation on the target
USB DAC at low volume. Android 16 reboot/update behavior, AAC, non-192 kHz
playback, and extended stability should also be checked on-device. Host and
package verification do not establish subjective audio quality or production
stability.
