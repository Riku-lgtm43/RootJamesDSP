# JamesDSP Orbit — Android 16 Config Label v38 Verification Report

This package inherits v37's unchanged native library and adds the Android 16
vendor config label correction. The device finding, package change, static
checks, and required on-device verification are in
[`Android16_Auxio_ConfigLabel_Verification.md`](Android16_Auxio_ConfigLabel_Verification.md).
The inherited v37 route findings are in
[`USB_HiFi_192k_Verification_Report.md`](USB_HiFi_192k_Verification_Report.md).
The v36 RMS normalization and headroom measurements remain in
[`AudioQuality_Verification_Report.md`](AudioQuality_Verification_Report.md).
