JamesDSP Orbit Stage 31 — Audio Quality Guard
Experimental KernelSU update — version 36
===============================================================================

STATUS
- This is a new, opt-in experimental update based on the working v35 candidate.
  The v35 package remains unchanged.
- Host testing found that the previous Orbit path could exceed float full scale
  with real Steam Audio HRTF output, especially at 96 kHz. This build requests
  RMS HRTF normalization and applies a stereo-linked block peak guard at 0.95
  with a 60 ms release. Non-finite HRTF results fall back to the original
  JamesDSP audio for that sample.
- Host testing used Steam Audio 4.8.1 with the packaged CIPIC SOFA at 44.1,
  48, and 96 kHz. It is not an Android device listening test. Low-volume
  LDAC testing and AAC/USB controls remain required.
- The 128-frame bridge still adds up to 128 frames of Orbit latency. This is
  not a production-stable release.

IDENTITY AND PRESERVED FILES
- KernelSU module ID remains jamesdsp_orbit_stage29. Install only as an
  in-place opt-in update, never as a second module.
- The signed JamesDSP APK and certificate, audio_effects.xml,
  libc++_shared.so, libphonon.so, customize.sh, CIPIC SOFA data, license notice,
  and Orbit effect UUID are preserved byte-for-byte from v35.
- The JamesDSP DSP core objects are reused byte-for-byte from v35. Only the
  Orbit SteamSpatial object was rebuilt for this audio-quality candidate.
- No JKS, signing password, or signing secret is included.

INSTALL AND ROLLBACK
1. Back up the installed module, app settings, and known-good Stage 31 ZIP.
2. Install through KernelSU Manager as an in-place update; do not flash from
   recovery or install a second module.
3. Test briefly at low volume with Orbit OFF/ON at LDAC 44.1, 48, and 96 kHz.
   Stop on crackle, pops, dropouts, silence, abnormal balance, or volume. Then
   check AAC and USB separately.
4. For rollback, disable the experimental module in KernelSU Manager and
   reboot, then restore the saved v35/Stage 31 package and reboot.

VERIFICATION
See reference/AudioQuality_Verification_Report.md for the build, audio tests,
protected payload checks, and limitations. The CIPIC redistribution notice is
at licenses/CIPIC-HRTF-NOTICE.txt.
