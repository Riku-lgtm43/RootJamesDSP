JamesDSP Orbit Stage 31 — LDAC Frame Bridge + High-Rate CIPIC HRTF Experimental
===============================================================================

STATUS
- Experimental opt-in KernelSU update for rooted ARM64 devices; not a stable release.
- Includes the previously tested 128-frame Orbit bridge that the user reported
  resolved LDAC 44.1/48 kHz crackling. This package changes HRTF selection only
  at 88.2/96 kHz; repeat short 44.1/48 tests after updating.
- At 44.1/48 kHz Orbit keeps Steam Audio's embedded default HRTF.
- At 88.2/96 kHz Orbit loads the bundled CIPIC 124 SOFA file. The exact Stage 31
  Steam Audio library successfully created this SOFA HRTF at both rates for
  frame sizes 128, 256, 512, and 1024 in the supplied Termux matrix.
- The matrix verifies HRTF initialization, not audible Orbit output. Device
  playback, transitions across route changes, long-duration stress testing,
  AAC/USB regression, and Android 16 reboot/install testing remain pending.
- The bridge adds 128 frames of latency while Orbit is enabled.

IDENTITY AND PRESERVED FILES
- Existing KernelSU module ID: jamesdsp_orbit_stage29; install as an in-place
  opt-in update, never as a second module.
- Existing JamesDSP effect UUID and registration are preserved.
- Signed JamesDSP APK and certificate, audio_effects.xml, libc++_shared.so,
  libphonon.so, installer, module ID, and effect UUID are byte-identical to the
  prior frame-bridge package / Stage 31 base as applicable.
- The only new system payload is the CIPIC SOFA data file. Other additions or
  changes are module metadata, documentation, test records, and its license
  notice.
- The Orbit native library is rebuilt from the archival Stage 18 source plus
  the committed frame-bridge and high-rate HRTF patch. No other DSP component
  was rebuilt or changed.
- The CIPIC HRTF notice and attribution are in licenses/CIPIC-HRTF-NOTICE.txt.

INSTALL ONLY AFTER BACKUP
1. Back up the installed module, JamesDSP app data/settings, and the known-good
   Stage 31 and frame-bridge ZIPs.
2. This package updates the existing module ID in place. Use KernelSU Manager;
   do not install a second copy or flash it from recovery.
3. Reboot only when you choose. Confirm module activation, mounted SOFA file
   readability, installed library hashes, effect registration, and SELinux
   vendor_file labels.
4. At low volume, test Orbit OFF/ON separately at LDAC 44.1, 48, 88.2, and
   96 kHz. Check logs with `logcat -s JamesDSPOrbit AxionFxSpatial` and confirm
   the CIPIC SOFA path initialized at 88.2/96. Then test AAC and USB controls.
5. Stop immediately on crackle, popping, dropout, silence, or abnormal levels.
   Do not begin extended playback until short tests are clean.

ROLLBACK
Disable the experimental module in KernelSU Manager and reboot. Restore the
saved known-good Stage 31/frame-bridge package and reboot. Preserve app data if
an APK signing or package conflict appears.

LIMITATIONS
The supplied matrix used the exact packaged Stage 31 libphonon.so and reports
successful HRTF creation with CIPIC SOFA at the tested rates and frame sizes.
It does not exercise this module's audio callback, acoustics, actual LDAC
playback, Android 16 installation, reboot persistence, or stress behavior.
Do not call 96 kHz Orbit fixed until the user verifies audible output on-device.
No automatic installation or system modification was performed.
