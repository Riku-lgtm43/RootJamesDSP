JamesDSP Orbit Stage 31 — LDAC Frame Bridge Experimental
=======================================================

STATUS
- Experimental opt-in KernelSU update for rooted ARM64 devices.
- NOT production stable. LDAC 44.1/48 crackling and 96 kHz inaudible Orbit
  were reported by the user. The 44.1/48 callback-tail behavior is addressed
  by a stateful 128-frame bridge, but device playback has NOT been validated.
- At 96 kHz the supplied dump showed stereo float audio at 96 kHz and 1,920
  frames. Orbit initialization status was not captured; this build adds
  non-real-time configuration and initialization logs to help distinguish
  rejected config from Steam Audio failure.
- The bridge adds 128 frames of latency while Orbit is enabled, with a short
  fade when the processed stream becomes available and a fade to dry on OFF.
- Offline mocked-Steam-Audio regression tests passed. This does not establish
  real Steam Audio behavior or hardware success.

IDENTITY AND CONTENTS
- Module ID remains jamesdsp_orbit_stage29 for opt-in in-place update.
- Effect UUID remains f27317f4-c984-4de6-9a90-545759495bf2.
- Only the Orbit native library, module metadata, README, reference hashes, and
  one build-provenance note differ from the Stage 31 base archive.
- The signed JamesDSP APK, signature, libphonon.so, libc++_shared.so,
  audio_effects.xml, installer script, and systemless layout are unchanged.
- libphonon.so is preserved byte-for-byte; no signing secrets are included.

INSTALL ONLY AFTER BACKUP
1. Keep a copy of the currently installed Stage 31 module ZIP and back up the
   current module directory and app settings.
2. This package intentionally updates the existing module ID in place. Do not
   install it as a second copy. Install through KernelSU Manager only; do not
   flash it from recovery or modify physical vendor files.
3. Reboot only when you choose to test. Verify module state, mounted hashes,
   effect registration, and SELinux vendor_file labels after boot.
4. Test at low volume and for short periods: Orbit OFF then ON on LDAC 44.1,
   48, and 96 kHz; then AAC and USB controls. Stop immediately if there is
   crackling, popping, dropouts, silence, or abnormal output level.
5. Do not perform extended playback until every short route test is clean.
   LDAC is not considered fixed until the user confirms device results.

DIAGNOSTICS
Use logcat -s JamesDSPOrbit AxionFxSpatial. Configuration logs show rate,
channel mask, format, and eligibility. Steam Audio logs show initialization
success or the failed API and status. No per-buffer logging is added.

ROLLBACK
If audio behaves abnormally, disable this module in KernelSU Manager and
reboot. Restore the saved Stage 31 ZIP through KernelSU Manager and reboot.
If the system app update causes a signature/data issue, preserve app data and
resolve that separately; do not blindly clear or uninstall user data.

BUILD/TEST LIMITS
The native candidate was rebuilt with Android NDK r27 Clang 18.0.1 using the
archival Stage 18 source and exact Stage 31 libphonon dependency. It is not a
byte-reproducible build of the deployed Stage 31 ELF. The offline harness
mocks the Steam Audio boundary; no device test, long-duration stress test,
or acoustic validation is claimed.
