JamesDSP Orbit Stage 31 — Android 16 Audio Config Label Candidate
Experimental KernelSU update — version 38
===============================================================================

STATUS
- This is an opt-in packaging update based on the v37 USB HiFi candidate. The
  Stage 31 release, v36 ZIP, and v37 ZIP remain unchanged.
- The supplied Auxio log records repeated SELinux denials when audioserver
  reads the overlaid audio_effects.xml, labeled vendor_file. Version 38 labels
  bundled /system/vendor/etc overlay files vendor_configs_file while keeping
  sound-effect libraries vendor_file. It adds no SELinux policy allow rule.
- The log maps Auxio PID 7848 to audio session 297 and records its MusicFx
  session opening. It does not show a successful JamesDSP effect creation for
  that session or its negotiated PCM configuration. The label denial is
  confirmed; its link to Auxio silence remains to be verified after reboot.
- This package changes only customize.sh, module metadata, and documentation.
  The v37 Orbit library, signed APK, Steam Audio libraries, and configuration
  payloads are unchanged.
- The supplied Android 16 capture shows the active USB effect at stereo-float
  192 kHz. The v36 Orbit selector used Steam Audio's embedded HRTF at 192 kHz.
  Exact-library checks confirm embedded entries at 24/44.1/48 kHz and failures
  at 88.2/96 kHz. The exact Android 192 kHz check remains pending, so this
  rate-selection mismatch is the strongest source-level explanation for Orbit
  not working, with the 192 kHz initialization failure still to be confirmed.
- The inherited v37 library keeps the embedded HRTF at 24/44.1/48 kHz and selects bundled
  CIPIC SOFA for other rates, including 192 kHz. Steam Audio 4.8.1 Linux host
  tests created and processed CIPIC HRTFs at 192 kHz with bounded finite output.
  The exact Android ARM64 library matrix and 192 kHz device playback remain
  pending.
- The capture's AudioFlinger mixer rate is 192 kHz while the ALSA USB snapshot
  reports 48 kHz. This ZIP does not establish the DAC hardware's active rate.
- This packaging change does not alter Enhanced-mode session handling or
  resolve its reported stability concerns.
- The 128-frame Orbit bridge still adds up to 128 frames of latency. This is
  not a production-stable release.

IDENTITY AND PRESERVED FILES
- KernelSU module ID remains jamesdsp_orbit_stage29. Install only as an
  in-place opt-in update, never as a second module.
- The signed JamesDSP APK and certificate, audio_effects.xml,
  libc++_shared.so, libphonon.so, CIPIC SOFA data, license notice, and Orbit
  effect UUID are preserved byte-for-byte from v37. customize.sh is the only
  runtime packaging file changed in v38.
- The v37 Orbit library is reused unchanged; v38 performs no native rebuild.
- No JKS, signing password, or signing secret is included.

INSTALL AND ROLLBACK
1. Back up the installed module, app settings, and known-good Stage 31 ZIP.
2. Install through KernelSU Manager as an in-place update; do not flash from
   recovery or install a second module.
3. After reboot, verify SELinux labels with `ls -Z` for
   `/vendor/etc/audio_effects.xml`, the CIPIC SOFA file, and both soundfx
   libraries. Confirm JamesDSP registers, then test Auxio with the master
   switch ON and OFF. Continue with a brief low-volume Orbit OFF/ON USB
   192 kHz test and ordinary 44.1/48 kHz playback. Stop on crackle, pops,
   dropouts, silence, abnormal balance, or volume.
4. For rollback, disable the experimental module in KernelSU Manager and
   reboot, then restore the saved Stage 31 package and reboot.

VERIFICATION
See reference/Android16_Auxio_ConfigLabel_Verification.md for the SELinux
finding, package change, checks, and device verification steps. The inherited
v37 Orbit findings are in reference/USB_HiFi_192k_Verification_Report.md. The ZIP checksum is
published in the matching .sha256 sidecar. See
reference/AudioQuality_Verification_Report.md for the unchanged v36 headroom
measurements. The CIPIC redistribution notice is at
licenses/CIPIC-HRTF-NOTICE.txt.
