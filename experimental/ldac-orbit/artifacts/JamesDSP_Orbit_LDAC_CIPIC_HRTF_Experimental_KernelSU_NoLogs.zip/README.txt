JamesDSP Orbit Stage 31 — LDAC Frame Bridge + High-Rate CIPIC HRTF
No diagnostic logging build — Experimental KernelSU update
===============================================================================

STATUS
- Short on-device playback was reported clean: no crackling/popping at LDAC
  44.1 and 48 kHz; Orbit was audible at the device's negotiated 96 kHz rate.
- The capture label “90 kHz” negotiated LDAC 96 kHz (supported choices shown
  by the device: 44.1, 48, 88.2, and 96 kHz).
- Rooted dumpsys and the preceding diagnostic build's logs showed JamesDSP/
  AxionFx active and successful Orbit Steam Audio initialization. At 96 kHz the
  candidate selected bundled CIPIC SOFA. Orbit-specific runtime diagnostics
  have been removed; the removed calls did not participate in DSP processing.
- Extended stress/stability, AAC/USB regression, Android 16 reboot/install,
  and playback on this refined no-logging binary remain pending.
- The 128-frame bridge adds up to 128 frames of processing latency while Orbit
  is enabled. This is an experimental update, not a production-stable release.

IDENTITY AND PRESERVED FILES
- KernelSU module ID remains jamesdsp_orbit_stage29. Install only as an
  in-place opt-in update, never as a second module.
- The signed JamesDSP APK and certificate, audio_effects.xml,
  libc++_shared.so, libphonon.so, customize.sh, and Orbit effect UUID are
  preserved byte-for-byte from the Stage 31 package.
- Embedded Steam Audio HRTF remains selected at 44.1/48 kHz; bundled CIPIC 124
  SOFA is selected at 88.2/96 kHz. SOFA data and its license notice are included.
- Only the experimental Orbit bridge library differs from the earlier
  experimental build. It removes diagnostic logs and tightens startup/off
  transitions, reset state, and high-rate HRTF failure handling. No DSP
  algorithms or unrelated native DSP/support objects were modified.

INSTALL AND ROLLBACK
1. Back up the installed module, app settings, and known-good Stage 31 ZIP.
2. Install through KernelSU Manager as an in-place update; do not flash from
   recovery or install a second module.
3. Test briefly at low volume with Orbit OFF/ON at LDAC 44.1, 48, and 96 kHz.
   The device's 90 kHz test selection negotiated 96 kHz. Stop on crackle, pops,
   dropouts, silence, or abnormal volume. Then check AAC and USB separately.
4. For rollback, disable the experimental module in KernelSU Manager and
   reboot, then restore the saved known-good package and reboot.

VERIFICATION
See reference/Verification_Report.md for build identity, protected payload
hashes, the exact-library HRTF matrix, sanitized host regression, ZIP checks,
and outstanding tests. The CIPIC HRTF redistribution notice is at
licenses/CIPIC-HRTF-NOTICE.txt. No JKS, signing password, or signing secret is
included.
