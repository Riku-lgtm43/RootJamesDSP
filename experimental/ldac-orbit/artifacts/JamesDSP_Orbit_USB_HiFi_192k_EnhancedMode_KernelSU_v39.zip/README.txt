JamesDSP Orbit Stage 31 — 192 kHz HRTF and Enhanced PCM candidate
Experimental KernelSU update — version 39
===============================================================================

STATUS
- Opt-in experimental update based on the v38 Android 16 config-label package.
  The Stage 31 release and v38 package are unchanged.
- At exactly 192 kHz, Orbit's CIPIC HRTF volume is set to 0.25 based on an
  offline real-HRTF response measurement. Other rates retain their previous
  volume setting.
- The native effect wrapper now acknowledges safe matching-rate PCM layouts
  rejected by the stereo DSP core and passes those samples through unchanged.
  DSP and Orbit effects are bypassed for those unsupported layouts; supported
  stereo routes keep their existing processing.
- Host tests pass, but Android 16 device installation, TikTok/Facebook playback,
  Apple Music 192 kHz listening, AAC/USB compatibility, and extended stress
  tests remain pending. This is not production-stable.

IDENTITY AND PRESERVED FILES
- KernelSU module ID remains jamesdsp_orbit_stage29. Install only as an
  in-place update, not as a second module.
- The signed JamesDSP APK and certificate, Steam Audio library,
  libc++_shared.so, audio_effects.xml, CIPIC SOFA and its attribution notice,
  and Android 16 config-label installer are preserved from v38.
- The JamesDSP DSP core and effect algorithm objects are unchanged. Only the
  native effect wrapper and Orbit spatial processor objects were rebuilt.
- No JKS, password, or signing secret is included.

INSTALL AND ROLLBACK
1. Back up the installed module, settings, and known-good Stage 31 ZIP.
2. Review reference/USB_HiFi_192k_EnhancedMode_v39_Verification_Report.md.
3. If you choose to test it, install through KernelSU Manager as an in-place
   update. Use low volume and stop if playback becomes silent, harsh, distorted,
   or unstable.
4. To roll back, disable the experimental module in KernelSU Manager and
   reboot, then restore the backed-up known-good module and reboot again.

VERIFICATION
- Full verification, remaining device checks, and checksums are in reference/.
- The CIPIC redistribution notice is in licenses/CIPIC-HRTF-NOTICE.txt.
